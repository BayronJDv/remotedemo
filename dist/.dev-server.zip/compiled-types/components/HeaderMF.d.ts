import React from 'react';
import './HeaderMF.css';
declare const HeaderMF: React.FC;
export default HeaderMF;
